<nav class="col-lg-2 col-sm-12 sidebar" id="sidebar">
    <ul class="nav nav-pills flex-column">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="#<?php echo e($category->id); ?>" class="collapsed"
               data-toggle="collapse"
               data-parent="#sidebar" aria-expanded="false"><p><?php echo e($category->name); ?></p></a>
            <?php if($category->subcategories->count()): ?>
                <div class="collapse" id="<?php echo e($category->id); ?>">
                    <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item mb-3"><a class="nav-link"
                                                     href="<?php echo e(route('product.category', $subcategory->id)); ?>"
                                                     data-parent="#<?php echo e($category->id); ?>"><?php echo e($subcategory->name); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</nav>
