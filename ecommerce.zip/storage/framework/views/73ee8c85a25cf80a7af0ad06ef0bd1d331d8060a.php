<?php $__env->startSection('title'); ?>
    PC SHOP
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if (Session::has('cart')): ?>
    <div class="row">
        <div class="col-sm-6 col-md-6 mx-auto mt-5">
            <ul class="list-group">
                <?php $__currentLoopData = $products;
                $__env->addLoop($__currentLoopData);
                foreach ($__currentLoopData as $product): $__env->incrementLoopIndices();
                    $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <strong>
                            <div><h2><?php echo e($product['item']['title']); ?></h2></div>
                        </strong>
                        <div><span>Price: <strong>$<?php echo e($product['price']); ?></strong></span>
                        </div>
                        <div class="btn-group pull-right">
                            <button class="btn btn-sm btn-warning dropdown-toggle" data-toggle="dropdown">Action
                                <span class="carret"></span></button>
                            <ul class="dropdown-menu mt-1 pl-3 border-dark">
                                <li>
                                    <a href="<?php echo e(route('product.reduceByOne', ['id' => $product['item']['id']])); ?>">Reduce
                                        by 1</a></li>
                                <li>
                                    <a href="<?php echo e(route('product.remove', ['id' => $product['item']['id']])); ?>">Reduce
                                        All</a></li>
                            </ul>
                        </div>
                        <span>Quantity: <strong><?php echo e($product['qty']); ?></strong></span>
                    </li>
                <?php endforeach;
                $__env->popLoop();
                $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6 col-md-6 mx-auto mt-5">
            <strong>Total: $<?php echo e($totalPrice); ?></strong>
            <hr>
        </div>

    </div>

    <div class="row">
        <div class="col-sm-6 col-md-6 mx-auto">
            <a href="<?php echo e(route('checkout')); ?>">
                <button type="button" class="btn btn-success">Checkout</button>
            </a>
        </div>
    </div>
<?php else: ?>
    <div class="row">
        <div class="col-sm-6 col-md-6 mx-auto mt-5">
            <h2>No items in cart</h2>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>