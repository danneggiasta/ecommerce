<?php $__env->startSection('title'); ?>
    PC SHOP
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-lg-8 col-xl-9 mt-5 ml-5">
            <h1 class="mb-5"><?php echo e($subcategory->name); ?></h1>
            <?php if(Session::has('success')): ?>
                <div class="row">
                    <div class="col-sm-6 col-md-4 mx-auto">
                        <div id="charge-message" class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="row">

                <?php $__currentLoopData = $subcategory->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-xl-3 col-lg-6 col-sm-6 d-flex align-items-stretch mb-5">

                        <a href="<?php echo e(route('product.show', ['id' => $sub->id])); ?>">
                            <div class="card">
                                <img class="card-img-top" src="<?php echo e($sub->imagePath); ?>" alt="">

                                <div class="card-block">
                                    <h4 class="card-title"><?php echo e($sub->title); ?>

                                    </h4>
                                    <h5>$ <?php echo e($sub->price); ?></h5>
                                    <p class="card-text"><?php echo e($sub->description); ?></p>
                                </div>
                                <div class="card-footer">
                                    <a href="<?php echo e(route('product.addToCart', ['id' => $sub->id])); ?>"
                                       class="btn btn-success pull-right" role="button">Add to Cart</a>
                                </div>
                            </div>
                        </a>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>