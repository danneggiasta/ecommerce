<?php $__env->startSection('title'); ?>
    PC SHOP
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-lg-8 col-xl-9 ml-5">
            <?php echo $__env->make('partials.carousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if(Session::has('success')): ?>
                <div class="row">
                    <div class="col-sm-6 col-md-4 mx-auto">
                        <div id="charge-message" class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-lg-6 col-sm-6 d-flex align-items-stretch mb-5">
                        <div class="card-deck">
                            <a href="<?php echo e(route('product.show', ['id' => $product->id])); ?>">
                            <div class="card">
                                <img class="card-img-top" src="<?php echo e($product->imagePath); ?>" alt="">
                                <div class="card-block">
                                    <h2 class="card-title"><?php echo e($product->title); ?>

                                    </h2>
                                    <h5>$ <?php echo e($product->price); ?></h5>
                                    <p class="card-text"><?php echo e($product->description); ?></p>
                                </div>
                                <div class="card-footer">
                                    <small class="text-muted">Category:</small>
                                    <p><?php echo e($product->sub_category->name); ?></p>
                                    <a href="<?php echo e(route('product.addToCart', ['id' => $product->id])); ?>"
                                       class="btn btn-success pull-right" role="button">Add to Cart</a>
                                </div>
                            </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- /.row -->
        </div>
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>