<?php $__env->startSection('title'); ?>
    PC SHOP
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">

        <?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="col-lg-7 ml-5 mt-5 mb-5">
            <div class="card">

                <div class="card-block">
                    <img class="card-img-top img-fluid  mb-2" src="<?php echo e($product->imagePath); ?>" alt="">
                    <h4 class="card-title"><a
                                href="<?php echo e(route('product.show', ['id' => $product->id])); ?>"><?php echo e($product->title); ?></a></h4>
                    <h5>$ <?php echo e($product->price); ?></h5>
                    <p class="card-text"><?php echo e($product->description); ?></p>
                </div>
                <div class="card-footer">
                    <small class="text-muted">Category:</small>
                    <p><?php echo e($product->sub_category->name); ?></p>
                    <a href="<?php echo e(route('product.addToCart', ['id' => $product->id])); ?>"
                       class="btn btn-success pull-right" role="button">Add to Cart</a>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>