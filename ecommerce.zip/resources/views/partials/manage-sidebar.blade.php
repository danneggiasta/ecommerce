<nav class="col-lg-2 col-md-2 hidden-xs-down bg-dark sidebar">
    <ul class="nav nav-pills flex-column">
        <li class="nav-item">
            <p>General</p>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Products</a>
        </li>
    </ul>

    <ul class="nav nav-pills flex-column mt-3">
        <li class="nav-item">
            <p>Administration</p>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Manage Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Roles</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Permissions</a>
        </li>
    </ul>
</nav>