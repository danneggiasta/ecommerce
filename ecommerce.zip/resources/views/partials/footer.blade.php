<!-- Footer -->
<footer class="bg-dark footer">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Zlatanović Nebojša 2017</p>
    </div>
    <!-- /.container -->
</footer>