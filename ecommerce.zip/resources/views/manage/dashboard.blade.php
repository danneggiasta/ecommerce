@extends('layouts.manage')

@section('content')
            <div class="col-lg-9 mt-5 ml-5">
                <div class="panel panel-default">
                    <div class="panel-heading">ADMIN Dashboard</div>

                    <div class="panel-body">
                    </div>
                </div>
            </div>
@endsection
